
Pro5console Usage:
Pro5console.exe -r Socks5IP:port -p chrome.exe
Pro5console.exe -r Socks5IP:port -user socks5name -password socks5password -p chrome.exe,firefox.exe


www.pro5.app